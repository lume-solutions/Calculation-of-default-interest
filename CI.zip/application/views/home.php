<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="assets/images/favicon.ico">

    <title>IZO Export/import</title>

    <!-- Bootstrap core CSS -->
    <link href="assets/bootstrap-3.3.7-dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="assets/bootstrap-3.3.7-dist/css/bootstrap-theme.css" rel="stylesheet">
    <link href="assets/css/font-awesome.min.css" rel="stylesheet">
    <link href="assets/css/main.min.css" rel="stylesheet">

  </head>

  <body>

    <div class="container">

      <!-- Static navbar -->
      <nav class="navbar navbar-default">
        <div class="container-fluid">
          <div class="navbar-header">
            <a class="navbar-brand" href="#">
              <img class="logo-TOP" src="assets/images/logo.png">IZO Export / Import
            </a>
          </div>
          <div class="navbar-right">
            <a href="http://izo.sodisce.si/izo-web/spring/izracun">
              <button class="btn btn-warning navbar-btn-right">
                <span class="fa fa-link"></span> Spletno mesto IZO
              </button>
            </a>
          </div>
        </div><!--/.container-fluid -->
      </nav>

      <!-- Main component -->
      <div class="jumbotron">
          <!-- TODO -->
      </div>

    </div> <!-- /container -->


    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script>window.jQuery || document.write('<script src="../../assets/js/vendor/jquery.min.js"><\/script>')</script>
    <script src="assets/bootstrap-3.3.7-dist/js/bootstrap.min.js"></script>
    <script type="text/javascript">
    	var pos = false;
    	$('.navbar-right').on('mouseover', function () {
    		if (pos) {
    			pos = false;
    			$(this).removeAttr('style');
    		} else {
    			pos = true;
    			$(this).css('margin-right', ($(this).width() * 1.2) + 'px');
    		}
    	});
    </script>
  </body>
</html>
